# s9180-root-kit-zcs — Galaxy S23 Ultra (SM-S9180/dm3q) 内存态 Root

适配 **Samsung Galaxy S23 Ultra (SM-S9180/dm3q / S9180ZCS8FZG1)**，基于 CVE-2026-43499 (GhostLock) + KernelSU。**grku 签名授权校验已去除**。

> **root 内存态，重启失效。KNOX e-fuse 风险自负。**

---

## 用法

```powershell
.\run_root_dm3q.ps1                 # 完整（推荐）
.\run_root_dm3q.ps1 --verify        # 只检查
.\run_root_dm3q.ps1 -Attempts 3     # 重试
```

```bat
run_root_dm3q.cmd
```

## 补丁

| 文件 | offset | 原始 | 补丁 |
|---|---|---|---|
| payload | 0x9480 | b.ne | nop |
| root | 0x22bc | b.ne | nop |
| root | 0x2304 | b.ne | nop |

只拆 grku Ed25519 签名授权（E101），保留 `verifying-kernel-access` 自校验。

## 常见问题

| 现象 | 处理 |
|---|---|
| `verification failed E101` | 未打补丁，用本包文件 |
| `operation failed` | 已成功过，**重启设备**后再跑 |
| 重启后 root 消失 | 正常。重跑脚本即可 |
