# s9180-root-kit — Galaxy S23 Ultra (SM-S9180/dm3q) 内存态 Root

适配 **Samsung Galaxy S23 Ultra (SM-S9180/dm3q / S9180ZHS8FZG1)**，基于 CVE-2026-43499 (GhostLock) 内核 UAF 提权 + KernelSU。**已去除 grku Ed25519 签名授权校验**。

> **root 是内存态，重启失效。KNOX e-fuse 风险自负。**

---

## 环境要求

| 项目 | 要求 |
|---|---|
| 设备 | SM-S9180 (dm3q)，固件 **S9180ZHS8FZG1** |
| 手机 | 开启 USB 调试，授权本机 |
| 电脑 | Windows，PowerShell 5.1+（双击 `.cmd` 也支持） |
| adb | **已内置**，无需安装 |

## 目录结构

```
s9180-root-kit/
├── run_root_dm3q.ps1      ← 一键脚本（PowerShell，推荐）
├── run_root_dm3q.cmd       ← 一键脚本（CMD 备用）
├── SHA256SUMS.txt          ← 完整性校验
├── adb-bin/                ← 内置 adb
├── payloads/
│   ├── dm3q-...__payload   ← exploit .so（签名校验已去除）
│   └── dm3q-...__root      ← root helper（签名校验已去除）
├── tools/
│   ├── ksud-samsung-...    ← KernelSU daemon
│   └── KernelSU_Manager_...← 管理器 App
└── logs/                   ← 运行日志
```

## 使用方法

```powershell
# PowerShell（推荐）
.\run_root_dm3q.ps1                 # 完整流程
.\run_root_dm3q.ps1 --verify        # 只检查设备
.\run_root_dm3q.ps1 -Attempts 3     # 重试 3 次
.\run_root_dm3q.ps1 --skip-push     # 跳过推送
.\run_root_dm3q.ps1 --no-app        # 不装 Manager App
```

```bat
rem CMD 备用
run_root_dm3q.cmd
run_root_dm3q.cmd --verify
```

若 PowerShell 提示执行策略限制：
```powershell
powershell -ExecutionPolicy Bypass -File .\run_root_dm3q.ps1
```

## 流程

1. 固件检查 → 2. 推送文件 → 3. 预热 → 4. LD_PRELOAD 触发 exploit → 5. 验证 root → 6. KernelSU late-load → 7. 安装 Manager App

## 常见问题

| 现象 | 处理 |
|---|---|
| `verification failed E101` | 说明未打补丁，用本包文件 |
| `operation failed` | 上一轮已成功，**重启设备**后再跑 |
| 重启后 root 消失 | 正常（内存态），重跑脚本即可 |
| PowerShell 无法执行 | 加 `-ExecutionPolicy Bypass` |

## 补丁说明

- `payload @ 0x9480`: b.ne → nop
- `root @ 0x22bc`: b.ne → nop
- `root @ 0x2304`: b.ne → nop
- 只拆 grku 签名授权校验，保留 `verifying-kernel-access` 内核偏移自校验
